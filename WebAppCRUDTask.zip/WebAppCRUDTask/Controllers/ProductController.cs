﻿using Microsoft.AspNetCore.Mvc;
using WebAppCRUDTask.DataAccess;
using WebAppCRUDTask.Models;

namespace WebAppCRUDTask.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductRepository _repository;

        public ProductController(IConfiguration configuration)
        {
            _repository = new ProductRepository(configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<IActionResult> Index()
        {
            var products = await _repository.GetAllProductsAsync();
            return View(products);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(Products product)
        {
            if (ModelState.IsValid)
            {
                
                product.DateAdded = DateTime.Now;

                
                await _repository.AddProductAsync(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var product = await _repository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Products product)
        {
            if (ModelState.IsValid)
            {
               
                product.DateAdded = DateTime.Now; 
                await _repository.UpdateProductAsync(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _repository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var deletedRows = await _repository.DeleteProductAsync(id);
            if (deletedRows == 0)
            {
                return NotFound(); 
            }
            return RedirectToAction("Index");
        }





    }
}
