﻿using Microsoft.Data.SqlClient;
using System.Data;
using Dapper;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebAppCRUDTask.Models;

namespace WebAppCRUDTask.DataAccess
{
    public class ProductRepository
    {
        private readonly string _connectionString;

        public ProductRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IDbConnection Connection => new SqlConnection(_connectionString);

        
        public async Task<IEnumerable<Products>> GetAllProductsAsync()
        {
            using (var conn = Connection)
            {
                string sql = "SELECT * FROM Products";
                return await conn.QueryAsync<Products>(sql);
            }
        }

                public async Task<Products> GetProductByIdAsync(int id)
        {
            using (var conn = Connection)
            {
                string sql = "SELECT * FROM Products WHERE Id = @Id";
                return await conn.QueryFirstOrDefaultAsync<Products>(sql, new { Id = id });
            }
        }

        
        public async Task<int> AddProductAsync(Products product)
        {
            using (var conn = Connection)
            {
                string sql = "INSERT INTO Products (Name, Price, Description, DateAdded) VALUES (@Name, @Price, @Description, @DateAdded)";
                return await conn.ExecuteAsync(sql, new
                {
                    product.Name,
                    product.Price,
                    product.Description,
                    product.DateAdded
                });
            }
        }

        public async Task<int> UpdateProductAsync(Products product)
        {
            using (var conn = Connection)
            {
                
                string sql = "UPDATE Products SET Name = @Name, Price = @Price, Description = @Description WHERE Id = @Id";

                return await conn.ExecuteAsync(sql, new { product.Name, product.Price, product.Description, product.Id });
            }
        }

        
        public async Task<int> DeleteProductAsync(int id)
        {
            using (var conn = Connection)
            {
                string sql = "DELETE FROM Products WHERE Id = @Id";
                return await conn.ExecuteAsync(sql, new { Id = id });
            }
        }
    }
}
